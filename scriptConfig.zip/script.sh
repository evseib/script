
# pacman paralelo =15
sudo mv files/pacman.conf /etc/pacman.conf

sudo pacman -Syu

sudo pacman -S unzip pacman-contrib git base-devel xdg-user-dirs amd-ucode gufw ntfs-3g btop 
sudo pacman -S vlc firefox unrar tar rsync  neofetch kitty

# cria os diretorios de usuario
sudo xdg-user-dirs-update

#configura cores do bash
cd files
sudo cp -R Linux_terminal_color/DIR_COLORS /etc/
sudo cp Linux_terminal_color/bash.bashrc /etc/bash.bashrc
sudo cp Linux_terminal_color/.bashrc /root/.bashrc
cp Linux_terminal_color/.bashrc ~/.bashrc

# limpa cache do pacman
sudo systemctl enable paccache.timer

# instala yay
cd ~/Downloads
git clone https://aur.archlinux.org/yay.git
cd yay
makepkg -si
cd ..
rm -rf yay

# instala pacotes adicionais
sudo pacman -S enchant ttf-liberation ttf-bitstream-vera pkgstats adobe-source-sans-pro-fonts 
sudo pacman -S ttf-droid ttf-ubuntu-font-family a52dec faac faad2 flac jasper lame libdca 
sudo pacman -S libmad libmpeg2 libtheora libvorbis libxv x264 xvidcore  noto-fonts 
sudo pacman -S noto-fonts-emoji ttf-croscore ttf-roboto  ffmpeg gst-plugins-ugly 
sudo pacman -S gst-plugins-good gst-plugins-base gst-plugins-bad gst-libav gstreamer 

yay -S arc-gtk-theme flatplat-theme-git vertex-themes 



